# Problem Name: No Idea!
# HackerRank Link: https://www.hackerrank.com/challenges/no-idea/problem[cite: 13]

if __name__ == '__main__':
    n, m = map(int, input().split())
    arr = list(map(int, input().split()))
    set_a = set(map(int, input().split()))
    set_b = set(map(int, input().split()))
    
    happiness = 0
    for i in arr:
        if i in set_a:
            happiness += 1
        elif i in set_b:
            happiness -= 1
            
    print(happiness)