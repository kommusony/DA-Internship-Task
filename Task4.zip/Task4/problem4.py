# Problem Name: Loops
# HackerRank Link: https://www.hackerrank.com/challenges/python-loops/problem[cite: 9]

if __name__ == "__main__":
  n = int(input())
  for i in range(n):
    print(i**2)