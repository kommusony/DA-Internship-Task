# Problem Name: Finding the Percentage
# HackerRank Link: https://www.hackerrank.com/challenges/finding-the-percentage/problem[cite: 9]

if __name__ == "__main__":
  n = int(input())
  student_marks = {}
  for _ in range(n):
    name, *line = input().split()
    scores = list(map(float, line))
    student_marks[name] = scores
  query_name = input()

  query_scores = student_marks[query_name]
  average = sum(query_scores) / len(query_scores)
  print(f"{average:.2f}")