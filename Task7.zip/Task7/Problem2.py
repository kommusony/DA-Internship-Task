# Problem Name: The Captain's Room
# HackerRank Link: https://www.hackerrank.com/challenges/py-the-captains-room/problem

if __name__ == '__main__':
    k = int(input())
    rooms = list(map(int, input().split()))
    
    room_set = set(rooms)
    captain_room = (sum(room_set) * k - sum(rooms)) // (k - 1)
    print(captain_room)