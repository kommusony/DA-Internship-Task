# Problem Name: CamelCase
# HackerRank Link: https://www.hackerrank.com/challenges/camelcase/problem

import math
import os
import random
import re
import sys

def camelcase(s):
    count = 1
    for char in s:
        if char.isupper():
            count += 1
    return count

if __name__ == '__main__':
    s = input()
    result = camelcase(s)
    print(result)