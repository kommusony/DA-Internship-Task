# Problem Name: String Formatting
# HackerRank Link: https://www.hackerrank.com/challenges/python-string-formatting/problem[cite: 14]

def print_formatted(number):
    width = len(bin(number)[2:])
    for i in range(1, number + 1):
        dec = str(i)
        octal = oct(i)[2:]
        hex_val = hex(i)[2:].upper()
        binary = bin(i)[2:]
        print(f"{dec.rjust(width)} {octal.rjust(width)} {hex_val.rjust(width)} {binary.rjust(width)}")

if __name__ == '__main__':
    n = int(input())
    print_formatted(n)