# Problem Name: Python: Division
# HackerRank Link: https://www.hackerrank.com/challenges/python-division/problem[cite: 14]

if __name__ == '__main__':
    a = int(input())
    b = int(input())
    print(a // b)
    print(a / b)