# Problem Name: Arithmetic Operators
# HackerRank Link: https://www.hackerrank.com/challenges/python-arithmetic-operators/problem[cite: 14]

if __name__ == '__main__':
    a = int(input())
    b = int(input())
    print(a + b)
    print(a - b)
    print(a * b)